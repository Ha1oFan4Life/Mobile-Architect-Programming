package com.example.weighttrackingapp;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

/**
 * Optional placeholder activity from template.
 * Not used in the app flow (LoginActivity is the launcher).
 */
public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
